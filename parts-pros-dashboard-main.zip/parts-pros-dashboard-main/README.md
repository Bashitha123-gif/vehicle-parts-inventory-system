# Auto Parts Hub (23)

Create a modern, professional frontend UI for a **Vehicle Parts Inventory Management System** designed for a small vehicle parts sales shop.

## Important Technology Requirements

The frontend must be compatible with a standard **Vite + React + TypeScript** project.

Use:

* React
* TypeScript
* Vite 8.x
* React Router DOM
* Tailwind CSS
* Lucide React icons
* Axios-ready architecture
* TanStack Query-ready architecture

Do NOT use:

* TanStack Start
* Next.js
* Remix
* Nitro
* SSR
* Lovable-specific packages
* `@lovable.dev/vite-tanstack-config`
* `server.ts`
* `start.ts`
* `routeTree.gen.ts`
* Any framework-specific routing system

The project must run with:

```bash
npm run dev
```

using the normal Vite development server.

---

# Project Structure

Generate the frontend using this structure:

```text
frontend/
│
├── public/
│
├── src/
│   │
│   ├── assets/
│   │
│   ├── components/
│   │   ├── ui/
│   │   │   ├── Button.tsx
│   │   │   ├── Input.tsx
│   │   │   ├── Card.tsx
│   │   │   ├── Modal.tsx
│   │   │   ├── DataTable.tsx
│   │   │   └── Badge.tsx
│   │   │
│   │   ├── layout/
│   │   │   ├── DashboardLayout.tsx
│   │   │   ├── Sidebar.tsx
│   │   │   ├── Navbar.tsx
│   │   │   └── PageHeader.tsx
│   │   │
│   │   └── common/
│   │       ├── LoadingSpinner.tsx
│   │       ├── EmptyState.tsx
│   │       └── ConfirmDialog.tsx
│   │
│   ├── pages/
│   │   ├── auth/
│   │   │   └── Login.tsx
│   │   │
│   │   ├── dashboard/
│   │   │   └── Dashboard.tsx
│   │   │
│   │   ├── categories/
│   │   │   ├── Categories.tsx
│   │   │   └── CategoryForm.tsx
│   │   │
│   │   ├── brands/
│   │   │   └── Brands.tsx
│   │   │
│   │   ├── products/
│   │   │   └── Products.tsx
│   │   │
│   │   ├── suppliers/
│   │   │   └── Suppliers.tsx
│   │   │
│   │   ├── customers/
│   │   │   └── Customers.tsx
│   │   │
│   │   ├── purchases/
│   │   │   └── Purchases.tsx
│   │   │
│   │   └── sales/
│   │       └── Sales.tsx
│   │
│   ├── routes/
│   │   ├── AppRoutes.tsx
│   │   └── ProtectedRoute.tsx
│   │
│   ├── context/
│   │   └── AuthContext.tsx
│   │
│   ├── services/
│   │   ├── api.ts
│   │   ├── auth.service.ts
│   │   └── category.service.ts
│   │
│   ├── hooks/
│   │   ├── useAuth.ts
│   │   └── useDebounce.ts
│   │
│   ├── types/
│   │   ├── auth.ts
│   │   ├── category.ts
│   │   └── product.ts
│   │
│   ├── lib/
│   │   └── utils.ts
│   │
│   ├── App.tsx
│   ├── main.tsx
│   └── index.css
│
├── .env
├── .gitignore
├── index.html
├── package.json
├── tsconfig.json
├── vite.config.ts
└── README.md
```

---

# Design Requirements

Create a modern SaaS-style admin dashboard suitable for a real vehicle parts shop.

The UI should be:

* Clean
* Professional
* Modern
* Responsive
* Desktop-first
* Mobile-friendly
* Easy to use
* Consistent across all pages

Use a professional business/admin dashboard visual style.

Avoid excessive gradients, unnecessary animations, overly rounded cards, and decorative elements that reduce usability.

Use clear spacing, typography, borders, shadows, and visual hierarchy.

---

# Main Layout

Create a dashboard layout with:

### Sidebar

Include:

* Dashboard
* Inventory

  * Products
  * Categories
  * Brands
* Purchases
* Sales
* Suppliers
* Customers
* Reports
* Settings

The sidebar should support:

* Active menu state
* Icons
* Collapsed/expanded state
* Responsive mobile behavior

### Top Navbar

Include:

* Search
* Notifications
* User profile
* User role
* Logout
* Mobile menu button

---

# Dashboard Page

Create a professional dashboard containing:

### Summary Cards

* Total Products
* Total Stock
* Today's Sales
* Today's Purchases
* Low Stock Items
* Total Customers

### Charts

Include placeholders/components for:

* Sales overview
* Purchase overview
* Sales vs purchases
* Top selling products

### Recent Activity

Show:

* Recent sales
* Recent purchases
* Recently added products

### Low Stock Section

Display:

* Product name
* SKU
* Current quantity
* Minimum quantity
* Stock status

---

# Login Page

Create a modern login page.

Fields:

* Username or Email
* Password

Actions:

* Login
* Remember me
* Forgot password

Show:

* Loading state
* Validation errors
* API error message
* Password visibility toggle

The login page must be visually separate from the dashboard layout.

---

# Category Management Page

Create a professional CRUD page.

Features:

* Page title
* Add Category button
* Search input
* Category table
* Pagination
* Edit action
* Delete action
* Empty state
* Loading state
* Error state

Table columns:

```text
Category
Description
Status
Created Date
Actions
```

Create/Edit modal:

```text
Category Name
Description
Status
Save
Cancel
```

---

# Product Management Page

Design a product management interface containing:

* Product search
* Category filter
* Brand filter
* Vehicle model filter
* Stock status filter
* Add Product button

Table:

```text
Image
Product Name
SKU
Category
Brand
Vehicle
Stock
Selling Price
Status
Actions
```

---

# Supplier Page

Include:

* Supplier search
* Add supplier
* Supplier table
* Supplier contact details
* Supplier status
* Edit/delete actions

---

# Customer Page

Include:

* Customer search
* Add customer
* Customer table
* Phone
* Email
* Total purchases
* Outstanding balance
* Actions

---

# Purchase Page

Create a purchase management interface.

Include:

* Supplier selection
* Purchase date
* Invoice number
* Product selection
* Quantity
* Purchase price
* Discount
* Total

Show purchase item table and total summary.

---

# Sales Page

Create a POS-style sales interface.

Include:

* Product search
* Product selection
* Customer selection
* Cart
* Quantity
* Unit price
* Discount
* Subtotal
* Grand total
* Payment method
* Complete Sale button

The interface should be optimized for quick shop counter usage.

---

# Reports Page

Create report dashboard UI with:

* Sales report
* Purchase report
* Stock report
* Profit report
* Customer report

Include:

* Date range filters
* Category filter
* Export button
* Tables
* Charts

---

# Reusable Components

Create reusable components rather than duplicating UI.

Important components:

```text
Button
Input
Select
Card
Modal
DataTable
Badge
Dropdown
PageHeader
Sidebar
Navbar
LoadingSpinner
EmptyState
ConfirmDialog
Pagination
SearchInput
```

All pages should use these reusable components.

---

# Routing

Use ONLY:

```text
react-router-dom
```

Create:

```text
AppRoutes.tsx
ProtectedRoute.tsx
```

Routes:

```text
/login
/dashboard

/categories
/brands
/products
/suppliers
/customers
/purchases
/sales
/reports
/settings
```

Protected routes should require authentication.

Do not use TanStack Router or TanStack Start routing.

---

# Authentication Architecture

Create an authentication context:

```text
AuthContext.tsx
```

It should be ready to work with a NestJS JWT backend.

Store JWT token securely using the project's chosen authentication approach.

Provide:

```text
login()
logout()
user
token
isAuthenticated
```

Create:

```text
ProtectedRoute.tsx
```

for authenticated pages.

---

# API Architecture

Create:

```text
src/services/api.ts
```

Use Axios.

Base URL should come from:

```text
VITE_API_URL
```

Example:

```env
VITE_API_URL=http://localhost:3000
```

Create separate service files:

```text
auth.service.ts
category.service.ts
```

The architecture should make it easy to add:

```text
product.service.ts
brand.service.ts
supplier.service.ts
customer.service.ts
purchase.service.ts
sale.service.ts
```

later.

---

# Important Backend Compatibility

The backend is built using:

```text
NestJS
TypeScript
Prisma ORM
PostgreSQL
JWT Authentication
```

The frontend should be designed to consume REST APIs from this backend.

Example:

```text
POST   /auth/login
POST   /auth/register

GET    /categories
GET    /categories/:id
POST   /categories
PATCH  /categories/:id
DELETE /categories/:id
```

---

# Code Quality

Use:

* TypeScript
* Functional React components
* React hooks
* Strong typing
* Reusable components
* Clean folder structure
* No duplicated code
* Clear component naming
* Clean imports

Do not generate unnecessary framework-specific files.

The final project must be a **standard Vite React TypeScript SPA** that can run directly with:

```bash
npm install
npm run dev
```

and must NOT require Lovable, TanStack Start, Nitro, SSR, or any proprietary platform configuration.

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/424ce738-f42e-4768-a6e7-58351e59b937).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
